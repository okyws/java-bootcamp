package interfaces;

public interface IAllowance {
  double calculateAllowance();
}
