package interfaces;

public interface ISalary {
  double calculateSalary();
}
