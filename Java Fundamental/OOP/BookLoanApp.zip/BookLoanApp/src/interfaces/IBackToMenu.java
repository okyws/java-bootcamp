package interfaces;

public interface IBackToMenu {
  public void backToMenu();
}
