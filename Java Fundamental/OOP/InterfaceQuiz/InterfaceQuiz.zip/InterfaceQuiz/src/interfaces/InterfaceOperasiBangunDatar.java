package interfaces;

public interface InterfaceOperasiBangunDatar {
  // Methods / Functions yang harus di Override
  public double getKeliling();

  public double getLuas();
}
