package interfaces;

public interface IUMKProvider {
  double getUMK();
}
