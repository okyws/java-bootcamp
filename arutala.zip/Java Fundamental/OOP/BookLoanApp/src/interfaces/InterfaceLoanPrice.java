package interfaces;

public interface InterfaceLoanPrice {
  double calculateBookLoanPrice();
}
