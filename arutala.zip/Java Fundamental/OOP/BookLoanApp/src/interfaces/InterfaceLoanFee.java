package interfaces;

public interface InterfaceLoanFee {
  double calculateLoanFee();
}
