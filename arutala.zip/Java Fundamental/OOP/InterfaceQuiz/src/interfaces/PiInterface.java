package interfaces;

public interface PiInterface {
  // Constanta nilai PI
  double PI_VALUE = 3.14;
}
