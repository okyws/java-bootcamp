public class main {
  public static void main(String[] args) {

    /*
     * Soal no3 pretest
     * int result = 2 * (4 + 3) - (6 / 2) + (9 % 4);
     * System.out.print(result);
     */

    /*
     * Soal no4
     * int X, Y;
     * X = 20;
     *
     * if (X < 20) {
     * Y = 10;
     * } else {
     * Y = 5;
     * }
     * System.out.println(X + " " + Y);
     */

    /*
     * Soal no 5
     * double M, N, O;
     *
     * if (M < 15) {
     * N = 7;
     * }
     *
     * if (N > 10) {
     * O = 4;
     * }
     *
     * if (O == 4) {
     * M = M + 4;
     * }
     *
     * if (M >= 15) {
     * N = N - 3;
     * }
     *
     * if (N == 9) {
     * O = O + N;
     * }
     *
     * Pernyataan yang benar : Jika N > 10, maka M akan bertambah 4
     */

    /*
     * Soal no 6
     * int a = 25;
     * boolean b = false;
     * if (a < 20 && b == false) {
     * a = 10;
     * b = true;
     * } else {
     * a = 30;
     * b = false;
     * }
     *
     * System.out.print("a: " + a + " b: " + b);
     *
     * pernyataan yang benar: Penulisan kondisi pada baris 3 adalah benar.
     */

    /*
     * soal no 7
     * int a = 70;
     * boolean b = true;
     * if (a > 60 && b == true) {
     * a = 20;
     * b = (a > 25);
     * } else {
     * a = 30;
     * b = (a > 35);
     * }
     *
     * System.out.print("A: " + a + " B: " + b);
     */

    /*
     * Soal no 8
     * int x, y, z;
     * // sample case
     * x = 20;
     * y = 20;
     *
     * if (x > y) {
     * x = x + 5;
     * } else {
     * x = x - 5;
     * }
     *
     * if (x == y) {
     * z = x + y;
     * z = x - y;
     * }
     *
     * System.out.println(x + " " + y);
     *
     * pernyatann yang benar: Jika X = 20 dan Y = 20 diperiksa pada baris 1, maka X
     * akan dikurangi 5
     */

    /*
     * Soal no 9
     * int i = 2;
     * while (i <= 64) {
     *
     * i = i * 2;
     * System.out.println("Padepokan 79");
     * }
     */

    /*
     * Soal no 10
     * int i = 20;
     * do {
     * System.out.println("Happy ke " + i);
     * i = i - 2;
     * } while (i >= 10);
     */

    /*
     * Soal no 11
     * int x, y, result;
     * x = 2;
     * result = 1;
     * while (x <= 5) {
     * result = result * x;
     * x = x + 1;
     * }
     * System.out.println("x: " + x + " result: " + result);
     */

    /*
     * soal no 12
     * int x, y, result;
     * x = 27;
     * result = 5;
     * do {
     * result = result + x;
     * x = x / 3;
     * } while (x >= 8);
     * System.out.println("x: " + x + " result: " + result);
     */

    /*
     * soal no 13
     * int i, sum;
     * i = 10;
     * sum = 0;
     *
     * while (i < 10) {
     * sum = sum + i;
     * i += 1;
     * }
     * System.out.println("Nilai i: " + i + " Nilai sum: " + sum);
     *
     */

    /*
     * soal no 14
     * int a, b, c;
     * a = 5;
     * b = 2;
     * c = 0;
     * System.out.println("A: " + a + " B: " + b + " C: " + c);
     * a = b + 4;
     * b = b * 2;
     * c = a - b * 3;
     * System.out.println("A: " + a + " B: " + b + " C: " + c);
     * a = a + 2;
     * b = b - 1;
     * c = a * b;
     * System.out.println("A: " + a + " B: " + b + " C: " + c);
     *
     * System.out.print("\n" + a + " " + b + " " + c);
     *
     */

    /*
     * soal no 15
     * int A = 24;
     * boolean B = false;
     *
     * if (A > 87 && B == false) {
     * A = 33;
     * B = (A < 14);
     * } else {
     * A = 89;
     * B = (A > 37);
     * }
     *
     * System.out.println(B);
     */

    /*
     * soal no 16
     * int i, j = 1;
     * int[] A = new int[10];
     *
     * for (i = 1; i <= A.length; i++) {
     * if (i % 2 == 0) {
     * A[j] = i;
     * j = j + 1;
     * System.out.print(i + " ");
     * }
     * }
     */

    /*
     * soal no 17 -20
     * menggunakan file Warnet.java
     */
  }
}
