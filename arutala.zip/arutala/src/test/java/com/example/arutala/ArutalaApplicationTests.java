package com.example.arutala;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ArutalaApplicationTests {

	@Test
	void contextLoads() {
	}

}
